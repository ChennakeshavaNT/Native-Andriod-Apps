package com.example.dice;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button rollButton;
        final int dicearray[]={R.drawable.dice1,
                R.drawable.dice2,
                R.drawable.dice3,
                R.drawable.dice4,
                R.drawable.dice5,
                R.drawable.dice6};
        rollButton=(Button)findViewById(R.id.b1);
        final ImageView ldice=(ImageView)findViewById(R.id.ldice);
        final ImageView rdice=(ImageView)findViewById(R.id.rdice);
        rollButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("Dice","Button Pressed");
                Random rand=new Random();
                int num=rand.nextInt(6)+1;
                Log.d("Dice","Random no.:"+num);
                ldice.setImageResource(dicearray[num]);
                num=rand.nextInt(6);
                rdice.setImageResource(dicearray[num]);

            }
        });
    }
}
